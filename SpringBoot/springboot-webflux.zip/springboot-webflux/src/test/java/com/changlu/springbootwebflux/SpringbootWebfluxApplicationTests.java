package com.changlu.springbootwebflux;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootWebfluxApplicationTests {

    @Test
    void contextLoads() {
    }

}
