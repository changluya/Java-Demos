package com.changlu.springboot.sm;
import cn.hutool.core.util.HexUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.crypto.BCUtil;
import cn.hutool.crypto.SecureUtil;
import cn.hutool.crypto.SmUtil;
import cn.hutool.crypto.asymmetric.KeyType;
import cn.hutool.crypto.asymmetric.SM2;
import com.changlu.springboot.sm.util.SM2Util;
import org.bouncycastle.jcajce.provider.asymmetric.ec.BCECPublicKey;
import org.junit.jupiter.api.Test;

import java.security.KeyPair;

public class SMUtilTest {

    // 生成的一组私钥、公钥进行测试
    private String privateKey = "308193020100301306072a8648ce3d020106082a811ccf5501822d0479307702010104207cd356206f6d32a1a817c9fca805e6ad17a7569f10f04262d59dc54e7511a1c2a00a06082a811ccf5501822da144034200045a9ad869ff808d49fda8410471a1f138f9759b33150a9b7178f8bf0e4b6253d6b35a2fc38ac6226724b0c28b33e933749f4c58599e0a73022f4eee6c03399225";
    private String publicKey = "3059301306072a8648ce3d020106082a811ccf5501822d034200045a9ad869ff808d49fda8410471a1f138f9759b33150a9b7178f8bf0e4b6253d6b35a2fc38ac6226724b0c28b33e933749f4c58599e0a73022f4eee6c03399225";
//    private String publicKeyQ = "04981070e26f624917f2717bcaadc000c928c91b49c9c218df33260cafa1d2243c2427fd3486884a67d390751ff4956e35466fb4b925a666229b22d36c26267d67";
//    private String privateKeyD = "057ab3e1e512e970023c16c545289ecf37dd2cb202daa24c42936f21daa061ac";

    // 随机生成的密钥对加密或解密
    @Test
    public void testRandomSM() {
        String text = "我是一段测试aaaa";
        // 随机生成
        KeyPair pair = SecureUtil.generateKeyPair("SM2");
        System.out.println("privateKey=>" + pair.getPrivate());
        System.out.println("publicKey=>" + pair.getPublic());
        System.out.println(pair.getPrivate().getFormat());
        System.out.println(pair.getPublic().getFormat());
        byte[] privateKey = pair.getPrivate().getEncoded();
        byte[] publicKey = pair.getPublic().getEncoded();
        SM2 sm2 = SmUtil.sm2(privateKey, publicKey);
        // 直接默认随机
//        SM2 sm2 = SmUtil.sm2();
        // 此时内部生成的是随机的公钥、密钥
        String encryptStr = sm2.encryptBcd(text, KeyType.PublicKey);
        String decryptStr = StrUtil.utf8Str(sm2.decryptFromBcd(encryptStr, KeyType.PrivateKey));
        System.out.println("encryptStr=>" + encryptStr);
        System.out.println("decryptStr=>" + decryptStr);
    }


    // 案例1：生成服务端公钥、私钥，前端js公钥、私钥
    @Test
    public void testDiySM() {
        String text = "我是一段测试aaaa";
        // 生成密钥对
        KeyPair keyPair = SM2Util.generateKeyPair();
        // 服务器端使用
        // 生成私钥
        String privateKey = HexUtil.encodeHexStr(keyPair.getPrivate().getEncoded());
        // 生成公钥
        String publicKey = HexUtil.encodeHexStr(keyPair.getPublic().getEncoded());
        System.out.println("privateKey=>" + privateKey);
        System.out.println("publicKey=>" + publicKey);

        // 前端使用
        // 生成公钥 Q，以Q值做为js端的加密公钥
        String publicKeyQ = HexUtil.encodeHexStr(((BCECPublicKey) keyPair.getPublic()).getQ().getEncoded(false));
        System.out.println("公钥Q:"+ publicKeyQ);
        // 生成私钥 D，以D值做为js端的解密私钥
        String privateKeyD = HexUtil.encodeHexStr(BCUtil.encodeECPrivateKey(keyPair.getPrivate()));
        System.out.println("私钥D:"+ privateKeyD);

        // 服务端加解密
        String encodeStr = SM2Util.encrypt(text, privateKey, publicKey);
        String formatStr = SM2Util.decrypt(encodeStr, privateKey, publicKey);
        System.out.println("encodeStr=>" + encodeStr);
        System.out.println("formatStr=>" + formatStr);
    }

    // 案例2：客户端加密，服务端完成解密
    @Test
    public void testDecrypt() {
        String encodeStr = "042690ad14344234388b0b9466d05e46af83ff423c0e0195999fedc28d85b650cde76d3995547a7b071cccef5be1b8a81480de5026940b75e388c23015fea55dec348417ee2e20a82d52c170b3ab040d14cde02531ec649b781e7e4339a9c8e64556c87950ab97";
        String formatStr = SM2Util.decrypt(encodeStr, privateKey, publicKey);
        System.out.println("formatStr=>" + formatStr);
    }

    // 案例3:服务端进行加密
    @Test
    public void testEncrypt() {
        String str = "changlu test test";
        String encodeStr = SM2Util.encrypt(str, privateKey, publicKey);
        System.out.println("encodeStr=>" + encodeStr);
    }

}
