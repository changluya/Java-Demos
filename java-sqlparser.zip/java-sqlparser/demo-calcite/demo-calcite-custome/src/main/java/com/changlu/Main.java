package com.changlu;

import org.apache.calcite.config.Lex;
import org.apache.calcite.sql.SqlNode;
import org.apache.calcite.sql.dialect.OracleSqlDialect;
import org.apache.calcite.sql.parser.SqlParseException;
import org.apache.calcite.sql.parser.SqlParser;
import org.apache.calcite.sql.parser.SqlParserImplFactory;
import org.apache.calcite.sql.parser.ddl.CustomSqlParserImpl;
import org.apache.calcite.sql.parser.impl.SqlParserImpl;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) throws SqlParseException {
        // 解析配置 - mysql设置
        SqlParser.Config mysqlConfig = SqlParser.configBuilder()
                // 定义解析工厂
                .setParserFactory(SqlParserImpl.FACTORY)
                .setLex(Lex.MYSQL)
                .build();
        // 创建解析器
        SqlParser parser = SqlParser.create("", mysqlConfig);
        // Sql语句
        String sql = "SELECT id, name FROM table1\n" +
                "UNION\n" +
                "SELECT id, name FROM table2;" +
                "SELECT id, name FROM table3;";
        // 解析sql
        SqlNode sqlNode = parser.parseQuery(sql);

        System.out.println(sqlNode.toSqlString(OracleSqlDialect.DEFAULT));
    }
}