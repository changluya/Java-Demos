package com.changlu.core.ast;

public abstract class SQLExpr {
}
