package org.example.callback.chatbot;

import com.alibaba.fastjson.JSONObject;
import com.dingtalk.open.app.api.models.bot.ChatbotMessage;
import com.dingtalk.open.app.api.models.bot.MessageContent;
import com.dingtalk.open.app.api.callback.OpenDingTalkCallbackListener;
import lombok.extern.slf4j.Slf4j;
import org.example.service.RobotPrivateMessageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * 机器人消息回调
 *
 * @author zeymo
 */
@Slf4j
@Component
public class ChatBotCallbackListener implements OpenDingTalkCallbackListener<ChatbotMessage, JSONObject> {
    private RobotPrivateMessageService robotPrivateMessageService;

    @Autowired
    public ChatBotCallbackListener(RobotPrivateMessageService robotPrivateMessageService) {
        this.robotPrivateMessageService = robotPrivateMessageService;
    }

    /**
     * https://open.dingtalk.com/document/orgapp/chatbots-send-one-on-one-chat-messages-in-batches
     *
     * @param message
     * @return
     */
    @Override
    public JSONObject execute(ChatbotMessage message) {
        try {
            MessageContent text = message.getText();
            String userId = message.getSenderStaffId();
            if (text != null) {
                String msg = text.getContent();
                log.info("receive bot message from user={}, msg={}", userId, msg);
                String openConversationId = message.getConversationId();
                try {
                    //发送机器人消息
                    robotPrivateMessageService.send("hello",userId);
                } catch (Exception e) {
                    log.error("send private message by robot error:" + e.getMessage(), e);
                }
            }
        } catch (Exception e) {
            log.error("receive private message by robot error:" + e.getMessage(), e);
        }
        return new JSONObject();
    }
}
